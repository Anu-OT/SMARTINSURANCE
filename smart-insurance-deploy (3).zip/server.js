import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import morgan from 'morgan';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';

dotenv.config();
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const app = express();
const PORT = process.env.PORT || 4000;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '*';
const SESSION_TIMEOUT_MINS = Number(process.env.SESSION_TIMEOUT_MINS || 15);
const LOCKOUT_THRESHOLD = Number(process.env.LOCKOUT_THRESHOLD || 5);
const LOCKOUT_WINDOW_MINS = Number(process.env.LOCKOUT_WINDOW_MINS || 15);
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(helmet());
app.use(cors({ origin: ALLOW_ORIGIN, credentials: true }));
app.use(express.json({ limit: '5mb' }));
app.use(morgan('dev'));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

const limiter = rateLimit({ windowMs: 15*60*1000, limit: 200 });
app.use(limiter);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB limit

function signToken(payload){ return jwt.sign(payload, JWT_SECRET, { expiresIn: `${SESSION_TIMEOUT_MINS}m` }); }
function auth(required=true){
  return async (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return required ? res.status(401).json({ error:'Unauthorized' }) : next();
    try { req.user = jwt.verify(token, JWT_SECRET); next(); }
    catch { return res.status(401).json({ error: 'Invalid or expired token' }); }
  }
}
function requireRole(...roles){
  return (req,res,next)=> (req.user && roles.includes(req.user.role)) ? next() : res.status(403).json({ error:'Forbidden' });
}

// Health
app.get('/api/health', (_,res)=> res.json({ ok:true }));

// Register
app.post('/api/register', async (req,res)=>{
  const { name, email, phone, password } = req.body || {};
  if(!name || !email || !phone || !password) return res.status(400).json({ error:'Missing fields' });
  const policy = password.length>=8 && /[A-Z]/.test(password) && /[a-z]/.test(password) && /\d/.test(password) && /[^A-Za-z0-9]/.test(password);
  if(!policy) return res.status(400).json({ error:'Password does not meet policy' });
  const client = await pool.connect();
  try{
    const exists = await client.query('SELECT id FROM users WHERE lower(email)=lower($1)', [email]);
    if (exists.rowCount) return res.status(409).json({ error:'Email already registered' });
    const id = 'u-' + Math.random().toString(36).slice(2,9);
    const hash = bcrypt.hashSync(password, 10);
    await client.query('INSERT INTO users(id,name,email,phone,password_hash,role,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)', [id,name,email,phone,hash,'customer',Date.now()]);
    return res.json({ ok:true });
  } catch(e){ console.error(e); return res.status(500).json({ error:'Server error' }); }
  finally{ client.release(); }
});

// Login
app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body || {};
  const client = await pool.connect();
  try{
    const r = await client.query('SELECT * FROM users WHERE lower(email)=lower($1)', [email||'']);
    if (!r.rowCount) return res.status(401).json({ error:'Invalid login credentials' });
    const u = r.rows[0];
    const now = Date.now();
    if (u.locked_until && now < Number(u.locked_until)) return res.status(423).json({ error: 'Account locked. Try later or reset password.' });
    const ok = bcrypt.compareSync(password||'', u.password_hash);
    if (!ok){
      const failed = Number(u.failed_logins||0) + 1;
      let locked_until = Number(u.locked_until||0);
      if (failed >= LOCKOUT_THRESHOLD) locked_until = now + LOCKOUT_WINDOW_MINS*60*1000;
      await client.query('UPDATE users SET failed_logins=$1, locked_until=$2 WHERE id=$3', [failed, locked_until, u.id]);
      return res.status(401).json({ error:'Invalid login credentials' });
    }
    await client.query('UPDATE users SET failed_logins=0, locked_until=0 WHERE id=$1', [u.id]);
    const token = signToken({ id: u.id, email: u.email, role: u.role, name: u.name });
    return res.json({ ok:true, token, user:{ id:u.id, name:u.name, email:u.email, role:u.role } });
  } catch(e){ console.error(e); return res.status(500).json({ error:'Server error' }); }
  finally{ client.release(); }
});

// Me
app.get('/api/me', auth(), async (req,res)=>{
  const client = await pool.connect();
  try{
    const r = await client.query('SELECT id,name,email,role FROM users WHERE id=$1', [req.user.id]);
    if (!r.rowCount) return res.status(404).json({ error:'Not found' });
    res.json(r.rows[0]);
  } finally{ client.release(); }
});

// List Claims
app.get('/api/claims', auth(), async (req,res)=>{
  const client = await pool.connect();
  try{
    if (req.user.role === 'admin'){
      const r = await client.query('SELECT * FROM claims ORDER BY created_at DESC');
      return res.json(r.rows);
    } else {
      const r = await client.query('SELECT * FROM claims WHERE user_id=$1 ORDER BY created_at DESC', [req.user.id]);
      return res.json(r.rows);
    }
  } finally{ client.release(); }
});

// Create Claim (with optional file upload)
app.post('/api/claims', auth(), upload.array('documents', 10), async (req,res)=>{
  const { policyNumber, accidentDate, location, vehiclePlate, vehicleMake, vehicleModel, vehicleYear, description } = req.body || {};
  if (!policyNumber || !accidentDate || !location || !vehiclePlate || !description) return res.status(400).json({ error:'Missing required fields' });
  const docs = (req.files||[]).map(f=> ({ name:f.originalname, url:`/uploads/${f.filename}`, size:f.size }));
  const client = await pool.connect();
  try{
    const id = 'c-' + Math.random().toString(36).slice(2,9);
    await client.query(`INSERT INTO claims(id,user_id,policy_number,accident_date,location,vehicle_plate,vehicle_make,vehicle_model,vehicle_year,description,documents,status,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [id, req.user.id, policyNumber, accidentDate, location, vehiclePlate, vehicleMake||null, vehicleModel||null, vehicleYear?Number(vehicleYear):null, description, JSON.stringify(docs), 'Under Review', Date.now()]);
    return res.json({ ok:true, id });
  } catch(e){ console.error(e); return res.status(500).json({ error:'Server error' }); }
  finally{ client.release(); }
});

// Update claim status (admin)
app.patch('/api/claims/:id/status', auth(), requireRole('admin'), async (req,res)=>{
  const { id } = req.params; const { status, note } = req.body || {};
  if (!['Under Review','Approved','Rejected'].includes(status)) return res.status(400).json({ error:'Invalid status' });
  const client = await pool.connect();
  try{
    const r = await client.query('UPDATE claims SET status=$1 WHERE id=$2 RETURNING id', [status, id]);
    if (!r.rowCount) return res.status(404).json({ error:'Not found' });
    const updId = 'cu-' + Math.random().toString(36).slice(2,9);
    await client.query('INSERT INTO claim_updates(id,claim_id,status,note,updated_by,updated_at) VALUES($1,$2,$3,$4,$5,$6)', [updId, id, status, note||null, req.user.id, Date.now()]);
    return res.json({ ok:true });
  } catch(e){ console.error(e); return res.status(500).json({ error:'Server error' }); }
  finally{ client.release(); }
});

// Settings (admin)
app.get('/api/settings', auth(), requireRole('admin'), async (req,res)=>{
  const client = await pool.connect();
  try{
    const r = await client.query('SELECT key, value FROM settings');
    const obj = {}; r.rows.forEach(row => obj[row.key] = row.value);
    res.json(obj);
  } finally{ client.release(); }
});
app.put('/api/settings', auth(), requireRole('admin'), async (req,res)=>{
  const client = await pool.connect();
  try{
    const entries = Object.entries(req.body||{});
    for (const [k,v] of entries){
      await client.query(`INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value`, [k, JSON.stringify(v)]);
    }
    res.json({ ok:true });
  } finally{ client.release(); }
});

// Reports
app.get('/api/reports/summary', auth(), async (req,res)=>{
  const client = await pool.connect();
  try{
    if (req.user.role === 'admin'){
      const r = await client.query("SELECT status, COUNT(*) as count FROM claims GROUP BY status");
      return res.json({ counts: Object.fromEntries(r.rows.map(x=>[x.status, Number(x.count)])) });
    } else {
      const r = await client.query("SELECT status, COUNT(*) as count FROM claims WHERE user_id=$1 GROUP BY status", [req.user.id]);
      return res.json({ counts: Object.fromEntries(r.rows.map(x=>[x.status, Number(x.count)])) });
    }
  } finally{ client.release(); }
});

// Fallback to frontend
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, ()=> console.log(`Smart Insurance (Postgres) running on http://localhost:${PORT}`));
