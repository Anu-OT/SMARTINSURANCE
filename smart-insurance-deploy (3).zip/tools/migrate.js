import fs from 'fs';
import path from 'path';
import url from 'url';
import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();
const { Client } = pg;
const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const sql = fs.readFileSync(path.join(__dirname, '..', 'migrations', '001_schema.sql'), 'utf8');
const client = new Client({ connectionString: process.env.DATABASE_URL });
(async ()=>{
  try {
    await client.connect();
    await client.query(sql);
    console.log('Migration complete.');
  } catch(e) {
    console.error(e);
    process.exit(1);
  } finally {
    await client.end();
  }
})();
