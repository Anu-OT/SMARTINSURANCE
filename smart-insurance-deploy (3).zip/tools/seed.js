import pg from 'pg';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
dotenv.config();
const { Client } = pg;
const client = new Client({ connectionString: process.env.DATABASE_URL });
async function run(){
  await client.connect();
  const now = Date.now();
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@smartinsurance.com';
  const adminPw = process.env.ADMIN_PASSWORD || 'password123';
  const adminHash = bcrypt.hashSync(adminPw, 10);
  const customerEmail = 'customer@smartinsurance.com';
  const customerHash = bcrypt.hashSync('password123', 10);

  // Upsert settings
  const settings = [
    ['lockoutThreshold', 5],
    ['lockoutWindowMins', 15],
    ['sessionTimeoutMins', Number(process.env.SESSION_TIMEOUT_MINS || 15)],
    ['notifyChannels', { email: true, sms: true, push: true }]
  ];
  for (const [k,v] of settings){
    await client.query(`INSERT INTO settings(key, value) VALUES ($1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`, [k, JSON.stringify(v)]);
  }

  // Upsert admin
  await client.query(`INSERT INTO users(id,name,email,phone,password_hash,role,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)
    ON CONFLICT (email) DO NOTHING`, ['u-admin','Admin',adminEmail,'+2348000000000',adminHash,'admin',now]);

  // Upsert customer
  await client.query(`INSERT INTO users(id,name,email,phone,password_hash,role,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)
    ON CONFLICT (email) DO NOTHING`, ['u-customer','Customer',customerEmail,'+2348111111111',customerHash,'customer',now]);

  // Seed sample claims
  await client.query(`INSERT INTO claims(id,user_id,policy_number,accident_date,location,vehicle_plate,vehicle_make,vehicle_model,vehicle_year,description,documents,status,created_at)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    ON CONFLICT (id) DO NOTHING`,
    ['c-1001','u-customer','POL-0001','2025-08-10','Lagos, NG','SMT-123AA','Toyota','Corolla',2018,'Rear-end collision in traffic.','[]','Under Review',now]);
  await client.query(`INSERT INTO claims(id,user_id,policy_number,accident_date,location,vehicle_plate,vehicle_make,vehicle_model,vehicle_year,description,documents,status,created_at)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    ON CONFLICT (id) DO NOTHING`,
    ['c-1002','u-customer','POL-0002','2025-07-20','Abuja, NG','ABC-456BB','Honda','Civic',2017,'Side swipe on highway.','[]','Approved',now-10000000]);
  await client.query(`INSERT INTO claims(id,user_id,policy_number,accident_date,location,vehicle_plate,vehicle_make,vehicle_model,vehicle_year,description,documents,status,created_at)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    ON CONFLICT (id) DO NOTHING`,
    ['c-1003','u-customer','POL-0003','2025-06-15','Ikeja, NG','DEF-789CC','Ford','Focus',2015,'Hit a parked car.','[]','Rejected',now-20000000]);

  console.log('Seed complete.');
  await client.end();
}
run().catch(e=>{ console.error(e); process.exit(1); });
