# Smart Insurance PLC — Ready-to-Deploy Repo (One-Click Render)

This repository is prepared for one-click deployment on Render (free tier). It contains a Node/Express backend, PostgreSQL migrations, and a placeholder responsive frontend. Replace `/public` with your React build for full UI.

## Quick deploy (Render)
1. Create a new GitHub repo and push these files.
2. On Render, click **New → Blueprint** → Connect your GitHub repo.
3. Render will create the web service and Postgres DB using `render.yaml`.
4. In Render, set the following environment variables for the web service:
   - `DATABASE_URL` (Render provides the DB connection string after DB creation)
   - `JWT_SECRET` (or leave auto-generated)
   - `ADMIN_EMAIL` (default: admin@smartinsurance.com)
   - `ADMIN_PASSWORD` (default: password123)
   - `ALLOW_ORIGIN` (set to your frontend origin or `*` for testing)
5. Deploy and wait for the public URL to appear.

## Local run
```bash
cp .env.example .env
# set DATABASE_URL to your local Postgres
npm install
npm run migrate
npm run seed
npm run dev
# open http://localhost:4000
```

## Demo accounts
- Admin: admin@smartinsurance.com / password123
- Customer: customer@smartinsurance.com / password123

## Notes
- File uploads are stored in `/uploads`. For production, replace with S3.
- Change `JWT_SECRET` and admin password in environment variables after deploy.
